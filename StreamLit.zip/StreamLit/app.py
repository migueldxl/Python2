import streamlit as st
import pandas as pd

st.write("Olá, mundo")

nome = "Miguel"
idade = 17

st.write("Meu nome é", nome, "e tenho", idade, "anos.")

st.divider()

df = pd.DataFrame({
    "Matéria": ["Português", "Matemática", "Python", "Frame"],
    "Nota": [5, 9, 7, 10]
})

st.title("Meu primeiro dash")

st.subheader(nome)

st.write(df)

st.divider()

item = st.selectbox(
    "Escolha um item do supermercado:",
    ["Arroz", "Feijão", "Leite", "Pão"]
)

precos = {
    "Arroz": 25.00,
    "Feijão": 8.00,
    "Leite": 5.00,
    "Pão": 10.00
}

def calcular_preco(item):
    return precos[item]

preco = calcular_preco(item)

st.write("Item escolhido:", item)
st.metric("Preço da compra", f"R$ {preco:.2f}")