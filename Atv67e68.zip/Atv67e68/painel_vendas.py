import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os

if not os.path.exists("vendas.csv"):

    np.random.seed(42)

    n = 200

    datas = pd.date_range(
        start="2025-01-01",
        end="2025-12-31",
        periods=n
    )

    lojas = np.random.choice(
        ["Loja Centro", "Loja Norte", "Loja Sul", "Loja Leste"],
        n
    )

    produtos = np.random.choice(
        ["Notebook", "Celular", "Tablet", "Fone", "Teclado",
         "Mouse", "Monitor", "Impressora"],
        n
    )

    categorias = {
        "Notebook": "Informática",
        "Celular": "Eletrônicos",
        "Tablet": "Eletrônicos",
        "Fone": "Acessórios",
        "Teclado": "Acessórios",
        "Mouse": "Acessórios",
        "Monitor": "Informática",
        "Impressora": "Informática"
    }

    precos = {
        "Notebook": 3500,
        "Celular": 2200,
        "Tablet": 1500,
        "Fone": 250,
        "Teclado": 180,
        "Mouse": 100,
        "Monitor": 1200,
        "Impressora": 900
    }

    regioes_loja = {
        "Loja Centro": "Centro",
        "Loja Norte": "Norte",
        "Loja Sul": "Sul",
        "Loja Leste": "Leste"
    }

    quantidade = np.random.randint(1, 10, n)

    preco_unitario = [
        precos[p] * np.random.uniform(0.9, 1.1)
        for p in produtos
    ]

    dados = pd.DataFrame({
        "data": datas,
        "loja": lojas,
        "produto": produtos,
        "categoria": [categorias[p] for p in produtos],
        "regiao": [regioes_loja[l] for l in lojas],
        "quantidade": quantidade,
        "preco_unitario": preco_unitario
    })

    dados.loc[5, "preco_unitario"] = np.nan
    dados.loc[15, "quantidade"] = np.nan

    dados.to_csv("vendas.csv", index=False)

df = pd.read_csv("vendas.csv")

print("Dataset carregado com sucesso!")
display(df.head())

df["data"] = pd.to_datetime(df["data"])

print(df.dtypes)

df["faturamento"] = (
    df["quantidade"] * df["preco_unitario"]
)

display(df.head())

print("INFORMAÇÕES DO DATASET:")
df.info()

print("\nVALORES AUSENTES:")
print(df.isnull().sum())

print("\nRESUMO ESTATÍSTICO:")
display(df.describe())

df["preco_unitario"] = df["preco_unitario"].fillna(
    df["preco_unitario"].mean()
)

df["quantidade"] = df["quantidade"].fillna(
    df["quantidade"].mean()
)

df["faturamento"] = (
    df["quantidade"] * df["preco_unitario"]
)

print("Valores nulos após tratamento:")
print(df.isnull().sum())

faturamento_loja = (
    df.groupby("loja")["faturamento"]
    .sum()
    .sort_values(ascending=False)
)

print("Faturamento total por loja:")
display(faturamento_loja)

ticket_medio = (
    df.groupby("loja")["faturamento"]
    .agg(["sum", "count"])
)

ticket_medio["ticket_medio"] = (
    ticket_medio["sum"] / ticket_medio["count"]
)

ticket_medio = ticket_medio.sort_values(
    "ticket_medio",
    ascending=False
)

print("Ticket médio por loja:")
display(ticket_medio)

produtos_vendidos = (
    df.groupby("produto")["quantidade"]
    .sum()
    .sort_values(ascending=False)
    .head(5)
)

print("Cinco produtos mais vendidos:")
display(produtos_vendidos)

df["mes"] = df["data"].dt.month

df["mes_ano"] = df["data"].dt.strftime("%m/%Y")

faturamento_mensal = (
    df.groupby("mes_ano")["faturamento"]
    .sum()
    .sort_index()
)

mes_maior = faturamento_mensal.idxmax()
valor_maior = faturamento_mensal.max()

mes_menor = faturamento_mensal.idxmin()
valor_menor = faturamento_mensal.min()

print("Mês com maior faturamento:")
print(mes_maior, "-", round(valor_maior, 2))

print("\nMês com menor faturamento:")
print(mes_menor, "-", round(valor_menor, 2))

print("\nResumo mensal:")
display(faturamento_mensal)

sns.set_style("whitegrid")
sns.set_palette("deep")

plt.figure(figsize=(10, 6))

sns.barplot(
    x=faturamento_loja.index,
    y=faturamento_loja.values
)

plt.title("Faturamento Total por Loja")
plt.xlabel("Loja")
plt.ylabel("Faturamento (R$)")

plt.xticks(rotation=20)

plt.tight_layout()

plt.savefig(
    "faturamento_por_loja.png",
    dpi=300
)

plt.show()

plt.figure(figsize=(12, 6))

plt.plot(
    faturamento_mensal.index,
    faturamento_mensal.values,
    marker="o"
)

plt.title("Evolução Mensal do Faturamento")
plt.xlabel("Mês/Ano")
plt.ylabel("Faturamento (R$)")

plt.xticks(rotation=45)

for x, y in zip(
    faturamento_mensal.index,
    faturamento_mensal.values
):
    plt.text(
        x,
        y,
        f"R$ {y:,.0f}",
        ha="center",
        va="bottom",
        fontsize=8
    )

plt.tight_layout()

plt.savefig(
    "evolucao_mensal_faturamento.png",
    dpi=300
)

plt.show()

faturamento_regiao = (
    df.groupby("regiao")["faturamento"]
    .sum()
    .sort_values(ascending=False)
)

plt.figure(figsize=(8, 8))

plt.pie(
    faturamento_regiao.values,
    labels=faturamento_regiao.index,
    autopct="%1.1f%%",
    startangle=90
)

plt.title("Distribuição do Faturamento por Região")

plt.tight_layout()

plt.savefig(
    "faturamento_por_regiao.png",
    dpi=300
)

plt.show()

plt.figure(figsize=(10, 6))

sns.scatterplot(
    data=df,
    x="quantidade",
    y="faturamento",
    hue="categoria",
    s=80
)

plt.title(
    "Relação entre Quantidade Vendida e Faturamento"
)

plt.xlabel("Quantidade Vendida")
plt.ylabel("Faturamento (R$)")

plt.legend(
    title="Categoria"
)

plt.tight_layout()

plt.savefig(
    "quantidade_faturamento_scatter.png",
    dpi=300
)

plt.show()

plt.figure(figsize=(10, 6))

sns.boxplot(
    data=df,
    x="categoria",
    y="preco_unitario"
)

plt.title(
    "Distribuição de Preços por Categoria"
)

plt.xlabel("Categoria")
plt.ylabel("Preço Unitário (R$)")

plt.xticks(rotation=20)

plt.tight_layout()

plt.savefig(
    "precos_por_categoria_boxplot.png",
    dpi=300
)

plt.show()

colunas_numericas = [
    "quantidade",
    "preco_unitario",
    "faturamento"
]

correlacao = df[colunas_numericas].corr()

plt.figure(figsize=(8, 6))

sns.heatmap(
    correlacao,
    annot=True,
    cmap="coolwarm",
    fmt=".2f"
)

plt.title("Correlação entre Variáveis Numéricas")

plt.tight_layout()

plt.savefig(
    "heatmap_correlacao.png",
    dpi=300
)

plt.show()


fig, axes = plt.subplots(
    1,
    2,
    figsize=(16, 6)
)

sns.barplot(
    x=faturamento_loja.index,
    y=faturamento_loja.values,
    ax=axes[0]
)

axes[0].set_title(
    "Faturamento por Loja"
)

axes[0].set_xlabel("Loja")
axes[0].set_ylabel("Faturamento (R$)")

axes[0].tick_params(
    axis="x",
    rotation=20
)

axes[1].pie(
    faturamento_regiao.values,
    labels=faturamento_regiao.index,
    autopct="%1.1f%%",
    startangle=90
)

axes[1].set_title(
    "Faturamento por Região"
)

plt.tight_layout()

plt.savefig(
    "painel_comparativo.png",
    dpi=300
)

plt.show()


resumo = pd.DataFrame({
    "Indicador": [
        "Faturamento Total",
        "Loja com Maior Faturamento",
        "Valor da Maior Loja",
        "Loja com Menor Faturamento",
        "Valor da Menor Loja",
        "Mês com Maior Faturamento",
        "Valor do Maior Mês",
        "Mês com Menor Faturamento",
        "Valor do Menor Mês",
        "Produto Mais Vendido",
        "Quantidade do Produto Mais Vendido"
    ],

    "Resultado": [
        df["faturamento"].sum(),
        faturamento_loja.idxmax(),
        faturamento_loja.max(),
        faturamento_loja.idxmin(),
        faturamento_loja.min(),
        mes_maior,
        valor_maior,
        mes_menor,
        valor_menor,
        produtos_vendidos.idxmax(),
        produtos_vendidos.max()
    ]
})

display(resumo)

os.makedirs("graficos", exist_ok=True)

arquivos_graficos = [
    "faturamento_por_loja.png",
    "evolucao_mensal_faturamento.png",
    "faturamento_por_regiao.png",
    "quantidade_faturamento_scatter.png",
    "precos_por_categoria_boxplot.png",
    "heatmap_correlacao.png",
    "painel_comparativo.png"
]


import shutil

for arquivo in arquivos_graficos:
    if os.path.exists(arquivo):
        shutil.copy(
            arquivo,
            os.path.join("graficos", arquivo)
        )

resumo.to_csv(
    "resumo_analitico.csv",
    index=False
)

print("====================================")
print("ATIVIDADE FINALIZADA!")
print("====================================")
print("Gráficos salvos na pasta: graficos/")
print("Resumo salvo como: resumo_analitico.csv")